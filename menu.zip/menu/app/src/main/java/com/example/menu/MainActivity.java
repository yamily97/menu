package com.example.menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {





        private Button btnOptionsMenu;
        private Button btnContextualMenu;
        private Button btnPopupMenu;
    private ContextMenu menu;
    private View v;
    private ContextMenu.ContextMenuInfo menuInfo;
    private Bundle savedInstanceState;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            btnOptionsMenu = findViewById(R.id.btnOptionsMenu);
            btnContextualMenu = findViewById(R.id.btnContextualMenu);
            btnPopupMenu = findViewById(R.id.btnPopupMenu);

            btnOptionsMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showOptionsMenu(v);
                }
            });

            btnContextualMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showContextualMenu(v);
                }
            });

            btnPopupMenu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showpopupMenu(v);
                }
            });
        }

        private void showOptionsMenu(View v) {
            PopupMenu popupMenu = new PopupMenu(this, v);
            MenuInflater inflater = popupMenu.getMenuInflater();
            inflater.inflate(R.menu.optionsmenu, popupMenu.getMenu());
            popupMenu.show();
        }

        private void showContextualMenu(View v) {
            registerForContextMenu(v);
            openContextMenu(v);
            unregisterForContextMenu(v);
        }

        private void PopupMenu(View v) {
            PopupMenu popupMenu = new PopupMenu(this, v);
            MenuInflater inflater = popupMenu.getMenuInflater();
            inflater.inflate(R.menu.popup_menu, popupMenu.getMenu());
            popupMenu.show();
        }


        public void onCreateContextMenu() {
            this.menu = menu;
            this.v = v;
            this.menuInfo = menuInfo;
            super.onCreateContextMenu(menu, v, menuInfo);
            getMenuInflater().inflate(R.menu.contextual_menu, menu);
        }


    @Override
            public boolean onCreateOptionsMenu(Menu menu) {
                getMenuInflater().inflate(R.menu.optionsmenu, menu);
                return true;
            }


            public boolean optionsmenu(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menuItemContextual:
                        goToContextualMenu();
                        return true;
                    case R.id.menuItemPopupMenu:
                        goToPopupMenu();
                        return true;
                    case R.id.menuItemMain:

                        return true;
                    case R.id.menuItemExit:
                        exitApp();
                        return true;
                    default:
                        return super.onOptionsItemSelected(item);
                }
            }

            private void goToContextualMenu() {

            }

            private void goToPopupMenu() {

            }

            private void exitApp() {
                finish();
            }







        private Button contextualButton;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            this.savedInstanceState = savedInstanceState;
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            contextualButton = findViewById(R.id.btnContextualMenu);

            registerForContextMenu(contextualButton);
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            super.onCreateContextMenu(menu, v, menuInfo);
            getMenuInflater().inflate(R.menu.contextual_menu, menu);
        }

        @Override
        public boolean onContextItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.menuItem1:
                    // Acción para el elemento del menú 1
                    return true;
                case R.id.menuItem2:
                    // Acción para el elemento del menú 2
                    return true;
                case R.id.menuItem3:
                    // Acción para el elemento del menú 3

                case R.id.menuItem4:
                    // Acción para el elemento salir 4


                    return true;
                default:
                    return super.onContextItemSelected(item);
            }





            private Button btnPopupMenu


            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                btnPopupMenu = findViewById(R.id.btnPopupMenu);



            }



                    btnPopupMenu.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showPopupMenu(v);
                        }


                        private void showPopupMenu(View v) {
                            PopupMenu popupMenu = new PopupMenu(this, v);
                            MenuInflater inflater = popupMenu.getMenuInflater();
                            inflater.inflate(R.menu.popup_menu, popupMenu.getMenu());
                            popupMenu.show();
                        }
                    }
        }
}







